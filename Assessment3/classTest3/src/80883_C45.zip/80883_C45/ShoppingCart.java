package shoppingCartSystem;

import java.util.*;

public class ShoppingCart {
    public static void main(String[] args) {
    	System.out.println("Enter the type of collection:");
        Scanner scanner = new Scanner(System.in);
        String collectionType = scanner.nextLine();
        Collection<Item> cart;
   

        switch (collectionType) {
            case "ArrayList":
                cart = new ArrayList<>();
                break;
            case "HashSet":
                cart = new HashSet<>();
                break;
            default:
                System.out.println("Invalid collection type");
                return;
        }

        while (true) {
            String input = scanner.nextLine();
            if (input.isEmpty()) break;

            String[] parts = input.split(" ");
            String name = parts[0];
            double price = Double.parseDouble(parts[1]);
            int quantity = Integer.parseInt(parts[2]);

            cart.add(new Item(name, price, quantity));
        }

        double totalPrice = 0;
        for (Item item : cart) {
            System.out.printf("  %s (%d x $%.2f) - $%.2f\n", item.name, item.quantity, item.price, item.getTotalPrice());
            totalPrice += item.getTotalPrice();
        }

        System.out.printf("Total Price: $%.2f\n", totalPrice);

        if (totalPrice > 100) {
            double discount = totalPrice * 0.10;
            System.out.printf("Discount (10%%): $%.2f\n", discount);
            totalPrice -= discount;
        }

        System.out.printf("Final Price: $%.2f\n", totalPrice);

        scanner.close();
    }
}
