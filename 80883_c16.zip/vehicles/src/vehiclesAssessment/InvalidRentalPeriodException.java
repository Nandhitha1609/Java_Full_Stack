package vehiclesAssessment;

public class InvalidRentalPeriodException extends Exception {
    public InvalidRentalPeriodException(String message) {
        super(message);
    }
}
