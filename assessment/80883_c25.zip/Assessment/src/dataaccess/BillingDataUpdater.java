package dataaccess;

public class BillingDataUpdater {
	public void updateBillingData() {

	}

}
