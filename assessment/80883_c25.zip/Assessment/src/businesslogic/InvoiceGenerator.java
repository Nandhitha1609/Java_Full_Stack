package businesslogic;

public class InvoiceGenerator {

 public void generateInvoice() {
    
 }
}
